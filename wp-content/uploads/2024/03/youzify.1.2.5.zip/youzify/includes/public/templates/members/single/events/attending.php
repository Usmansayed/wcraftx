<?php
echo "hamdolah";