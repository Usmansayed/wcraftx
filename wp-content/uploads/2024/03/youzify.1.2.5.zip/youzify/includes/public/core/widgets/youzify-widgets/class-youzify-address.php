<?php

class Youzify_Profile_Address_Info_Box_Widget extends Youzify_Profile_Info_Box_Widget {
}